const burger = document.getElementById('burger');
const navMenu = document.getElementById('navMenu');

burger.addEventListener('click', () => {
  navMenu.classList.toggle('show');
});


let currentSlide = 0;
const slides = document.querySelectorAll('.slide');
const dots = document.querySelectorAll('.dot');

function showSlide(index) {
  if(index >= slides.length) currentSlide = 0;
  else if(index < 0) currentSlide = slides.length - 1;
  else currentSlide = index;

  document.querySelector('.slides').style.transform = `translateX(-${currentSlide * 100}%)`;

  dots.forEach(dot => dot.classList.remove('active'));
  dots[currentSlide].classList.add('active');
}

document.querySelector('.next').addEventListener('click', () => showSlide(currentSlide + 1));
document.querySelector('.prev').addEventListener('click', () => showSlide(currentSlide - 1));

dots.forEach((dot, index) => {
  dot.addEventListener('click', () => showSlide(index));
});

let thumbIndex = 0;

function slidermoving(direction) {
  const wrapper = document.querySelector('.slider-wrapper');
  const itemsPerView = 4;
  const itemWidth = 113.8 + 20; // image width + gap
  const totalItems = wrapper.children.length;

  thumbIndex += direction;

  if (thumbIndex < 0) thumbIndex = 0;
  if (thumbIndex > totalItems - itemsPerView) {
    thumbIndex = totalItems - itemsPerView;
  }

  wrapper.style.transform = `translateX(-${thumbIndex * itemWidth}px)`;
}
