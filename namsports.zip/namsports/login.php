<?php
session_start();
error_reporting(E_ALL);
ini_set('display_errors', 1);

// Handle form submission
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $username = $_POST['username'];
    $password = $_POST['password'];

        if ($username === 'shpezo' && $password === 'shpezo11') {
        $_SESSION['loggedin'] = true; 
        header('location: dashboard.php');
        exit;
    } else {
        $error_message = "Invalid credentials."; 
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ADMINISTRATOR LOGIN</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css">
    <link rel="shortcut icon" href="assests/images/logo-side.jpg" type="image/x-icon">
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f4f4f4;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }
        .container {
            display: flex;
            width: 80%;
            max-width: 900px;
            background: white;
            border-radius: 8px;
            box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
        }
        .form-container {
            padding: 20px;
            flex: 1;
            display: flex;
            flex-direction: column;
            justify-content: center;
        }
        .form-container h1 {
            margin-bottom: 20px;
            color: #333;
            text-align: center;
        }
        .form-container label {
            margin-top: 10px;
            display: block;
            color: #666;
        }
        .form-container input {
            width: 100%;
            padding: 10px;
            margin-top: 5px;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
        }
        .form-container button {
            margin-top: 20px;
            padding: 10px;
            width: 30%;
            background-color: #5cb85c;
            border: none;
            color: white;
            font-size: 16px;
            border-radius: 4px;
            cursor: pointer;
        }
        .form-container button:hover {
            background-color: #4cae4c;
        }
        .image-container {
            flex: 1;
            background: url('assests/logim.jpg') no-repeat center center;
            background-size: cover;
            border-radius: 0 8px 8px 0;
        }
        .password-container {
            position: relative;
            margin-top: 10px;
        }
        .password-container input {
            padding-right: 40px; 
        }
        .eye-icon {
            position: absolute;
            right: 10px;
            top: 50%;
            transform: translateY(-50%);
            cursor: pointer;
            color: #666;
        }
    </style>
</head>
<body>
    <div class="container">
        <div class="form-container">
            <h1>ADMINISTRATOR LOGIN</h1>
            <?php if (isset($error_message)) echo "<p style='color:red;'>$error_message</p>"; ?>
            <form action="login.php" method="POST">
                <label for="username">Username:</label>
                <input type="text" id="username" name="username" required>
                <label for="password">Password:</label>
                <div class="password-container">
                    <input type="password" id="password" name="password" required>
                    <i class="fa-solid fa-eye eye-icon" id="togglePassword" onclick="togglePassword()"></i>
                </div>
                <button type="submit">Login</button>
            </form>
        </div>
        <div class="image-container"></div>
    </div>

    <script>
        function togglePassword() {
            const passwordField = document.getElementById('password');
            const eyeIcon = document.getElementById('togglePassword');
            if (passwordField.type === "password") {
                passwordField.type = "text";
                eyeIcon.classList.remove('fa-eye');
                eyeIcon.classList.add('fa-eye-slash');
            } else {
                passwordField.type = "password";
                eyeIcon.classList.remove('fa-eye-slash');
                eyeIcon.classList.add('fa-eye');
            }
        }
    </script>
</body>
</html>
