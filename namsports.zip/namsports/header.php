<div class="alert alert-light text-center" style="color: black;" role="alert">
  Free shipping on orders over Rs 3000 + free returns 
</div>
<nav class="navbar navbar-expand-lg bg-body-secoundry sticky-top">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php">
            <img src="assests/images/logo1051011071015335.png" alt="">
        </a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation" style="color:aliceblue">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item dropdown">
                    <a class="nav-link dropdown-toggle" href="#" id="menDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">Men</a>
                    <ul class="dropdown-menu" aria-labelledby="menDropdown">
                        <li>
                            <h6 class="dropdown-header" style="color:black">Clothing</h6>
                            <a class="dropdown-item" style="color:black" href="Products.php">T-Shirts & Tops</a>
                            <a class="dropdown-item"  style="color:black" href="#">Pants</a>
                            <a class="dropdown-item" style="color:black"  href="#">Shorts</a>
                            <a class="dropdown-item" style="color:black"  href="#">Jackets & Hoodies</a>
                        </li>
                        <li>
                            <h6 class="dropdown-header">Accessories</h6>
                            <a class="dropdown-item"  style="color:black" href="#">Hats</a>
                            <a class="dropdown-item"  style="color:black" href="#">Belts</a>
                            <a class="dropdown-item"  style="color:black" href="#">Watches</a>
                            <a class="dropdown-item"  style="color:black" href="#">Bags</a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Women</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Kids</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Sports</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Accessories</a>
                </li>
                <li class="nav-item">
                    <a class="nav-link" aria-current="page" href="#">Schools</a>
                </li>
            </ul>
            <form class="d-flex" role="search" action="search.php" method="GET" id="searchForm">
                <input class="form-control me-2" type="search" name="query" placeholder="Search" aria-label="Search" id="inputField" >
                <button class="btn btn-outline-light" type="submit">Search</button>
            </form>
            <div class="modal" id="alertModal" tabindex="-1" role="dialog">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Alert</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <p>Please search Products.</p>
                </div>
                <div class="modal-footer">
                    <button onclick="hideModalAndRefresh()" type="button" class="btn btn-secondary" data-dismiss="modal">OK</button>
                </div>
            </div>
        </div>
    </div>
    <div id="searchResult" style="margin-top: 20px;"></div>
            <script>
             const inputField = document.getElementById("inputField");
        const form = document.getElementById("searchForm");
        const okButton = document.getElementById("okButton");


       
        form.addEventListener("submit", (event) => {
           
            if (inputField.value.trim() === "") {
                
                event.preventDefault(); 
                $('#alertModal').modal('show');// Prevent form submission
                return; 
            }

            
        });
        okButton.addEventListener("click", () => {
            hideModalAndRefresh(); // Call the specific function
        });

        function hideModalAndRefresh() {
            $('#alertModal').modal('hide'); // Hide the modal
            location.reload(); // Refresh the page
        }
            </script>
            <?php
            if (isset($_GET['query'])) {    
                include 'search.php'; 
            }
            ?>
            <div class="sid-logo">
                <img src="assests/images/logo-side.jpg" alt="">
            </div>
        </div>
    </div>
</nav>
<style>
.dropdown-item{
  color: black;
}

.nav-link:hover{
color: white;
}
.nav-link a:hover{
    color: white;
}
</style>
<script>
    const loginUser = async () => {
        const username = document.getElementById('username').value;
        const password = document.getElementById('password').value;
        const messageDiv = document.getElementById('loginMessage');

        try {
            const response = await fetch('http://localhost/namsports/login.php', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ username, password }),
            });

            if (!response.ok) throw new Error('Login failed: ' + response.statusText);
            const result = await response.json();
            messageDiv.textContent = result.message;
            messageDiv.className = result.message === 'Login successful' ? 'text-success' : 'text-danger';
        } catch (error) {
            console.error('Login error:', error);
            messageDiv.textContent = 'An error occurred. Please try again.';
            messageDiv.className = 'text-danger';
        }
    };
</script>



<script>
    document.getElementById('loginButton').addEventListener('click', loginUser);
    async function fetchItems() {
        try {
            const response = await fetch('http://localhost/api.php');
            if (!response.ok) throw new Error('Network response was not ok');
            const items = await response.json();
            const itemsList = document.getElementById('itemsList');
            itemsList.innerHTML = ''; // Clear existing items
            items.forEach(item => {
                const li = document.createElement('li');
                li.textContent = item.name;
                itemsList.appendChild(li);
            });
        } catch (error) {
            console.error('Fetch error:', error);
        }
    }

   
    fetchItems();
</script>
