<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Search Results</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" />
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="assests/images/logo-side.jpg" type="image/x-icon">
    <link rel="stylesheet" href="style.css">
</head>
<body>

<div class="alert alert-light text-center" role="alert">
    Free shipping on orders over Rs 3000 + free returns 
</div>

<nav class="navbar navbar-expand-lg bg-body-light">
    <div class="container-fluid">
        <a class="navbar-brand" href="index.php"><img src="assests/images/logo1051011071015335.png" alt=""></a>
        <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarSupportedContent">
            <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                <li class="nav-item"><a class="nav-link" href="#">Men</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Women</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Kids</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Sports</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Accessories</a></li>
                <li class="nav-item"><a class="nav-link" href="#">Schools</a></li>
            </ul>
            <form class="d-flex" role="search" action="search.php" method="GET">
    <input class="form-control me-2" type="search" name="query" placeholder="Search" aria-label="Search">
    <button class="btn btn-outline-light" type="submit">Search</button>
</form>
        </div>
        <div class="sid-logo">
        <img src="assests/images/logo-side.jpg" alt="">
      </div>
    </div>
</nav>
<h1 class="text-center Feature" style="color:#333">SEARCH RESULTS</h1>
<div class="container">
    <div class="row" style="gap:100px">
        <?php
        if (isset($_GET['query'])) {
            $query = strtolower(trim($_GET['query']));

            // Sample products
            $products = [
                ["title" => "Men's Training Pants Regular", "image" => "assests/Feature products/1.jpg"],
                ["title" => "Men's Training Pant Tapered", "image" => "assests/Feature products/2.jpg"],
                ["title" => "Straw Lid Bottle 600ml", "image" => "assests/Feature products/3.jpeg"],
                ["title" => "Men's T-Shirts Round", "image" => "assests/Feature products/4.jpeg"],
                ["title" => "MKL 10 Back Pack", "image" => "assests/Feature products/bag.jpeg"],
                ["title" => "Vinchi Lite Shoes", "image" => "assests/Feature products/sho.JPG"],
                ["title" => "Sports Cap Bottle 950ml", "image" => "assests/Feature products/boot.jpeg"],
                ["title" => "Tumbler with Handle", "image" => "assests/Feature products/tumb.jpg"],
                ["title" => "Shin Guard Adult", "image" => "assests/Sports/1.jpg"],
                ["title" => "Pro Goal Keeping Gloves", "image" => "assests/Sports/glo.jpg"],
                ["title" => "Pro Bat", "image" => "assests/Sports/bat.jpg"],
                ["title" => "Pro Batting Pad", "image" => "assests/Sports/pad.jpg"],
            ];

            foreach ($products as $product) {
                if (strpos(strtolower($product["title"]), $query) !== false) {
                    echo '<div class="col-md-3 mb-3">';
                    echo '    <div class="card" style="width: 18rem;">';
                    echo '        <img src="' . $product["image"] . '" class="card-img-top" alt="' . $product["title"] . '">';
                    echo '        <div class="card-body">';
                    echo '            <h5 class="card-title">' . $product["title"] . '</h5>';
                    echo '        </div>';
                    echo '    </div>';
                    echo '</div>';
                }
            }
        }
        ?>
    </div>
</div>
<div class="container">
  <footer class="py-5">
    <div class="row">
      <div class="col-6 col-md-2 mb-3">
        <h3>Support</h3>
        <ul class="nav flex-column">
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">About Us</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Contact Us</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Terms & Conditions</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Privacy Policy</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Return & Exchange</a></li>
        </ul>
      </div>

      <div class="col-6 col-md-2 mb-3">
        <h3>CATEGORIES</h3>
        <ul class="nav flex-column">
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Men</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Women</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Kids</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Sports</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Accessories</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Schools</a></li>
        </ul>
      </div>

      <div class="col-md-5 offset-md-1 mb-3" style="margin-left:250px;">
        <form id="subscribeForm" action="email.php" method="POST" onsubmit="return validateEmail()">
          <h5>Subscribe For Updates</h5>
          
          <div class="d-flex flex-column flex-sm-row w-100 gap-2">
            <label for="newsletter1" class="visually-hidden">Email address</label>
            <input id="newsletter1" name="email" type="text" class="form-control" placeholder="Email address" required>
            <button class="btn btn-danger" type="submit">Submit</button>
          </div>
          
        </form>
      </div>
    </div>

    <div class="d-flex flex-column flex-sm-row justify-content-between py-4 my-4 border-top">
      <p>© 2024 Company, Inc. All rights reserved.</p>
      <ul class="list-unstyled d-flex">
        <li class="ms-3">
          <a class="link-body-emphasis" href="#">
            <svg class="bi" width="24" height="24">
              <use xlink:href="#twitter"><i class="fa-brands fa-twitter"></i></use>
            </svg>
          </a>
        </li>
        <li class="ms-3"><a class="link-body-emphasis" href="#"><svg class="bi" width="24" height="24"><use xlink:href="#instagram"><i class="fa-brands fa-instagram"></i></use></svg></a></li>
        <li class="ms-3"><a class="link-body-emphasis" href="#"><svg class="bi" width="24" height="24"><use xlink:href="#facebook"><i class="fa-brands fa-facebook-f"></i></use></svg></a></li>
      </ul>
    </div>
  </footer>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>

<style>
  .container {
      display: flex;
      justify-content: center;
      flex-wrap: wrap;
  }

  .container .card {
    position: relative;
    overflow: hidden;
    transition: transform 0.3s ease;

}

.container .card img {
    width: 100%; /* Ensure images are responsive */
    transition: opacity 0.5s ease; /* Smooth transition for opacity */
    
}

.container .card-body {
    position: absolute;
    top: 50%;
    left: 50%;
    transform: translate(-50%, -50%);
    opacity: 0; /* Initially hidden */
    transition: opacity 0.5s ease; /* Smooth transition */
    text-align: center;
    padding: 10px; /* Optional: add some padding */
   
}

.container .card:hover {
    background-color: rgba(0, 0, 0, 0.7); /* Black background with transparency */
    border: solid white;
    border-radius: none;
 
}

.container .card:hover img {
    opacity: 0.2; /* Dim the image on hover */
    
}

.container .card:hover .card-body {
    opacity: 1; 
    /* color: white; */
    cursor: pointer;
}
.container .card:hover h5{
  color: white;
}

</style>