

<div class="container">
  <footer class="py-5">
    <div class="row">
      <div class="col-6 col-md-2 mb-3">
        <h3>Support</h3>
        <ul class="nav flex-column">
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">About Us</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Contact Us</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Terms & Conditions</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Privacy Policy</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Return & Exchange</a></li>
        </ul>
      </div>

      <div class="col-6 col-md-2 mb-3">
        <h3>CATEGORIES</h3>
        <ul class="nav flex-column">
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Men</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Women</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Kids</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Sports</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Accessories</a></li>
          <li class="nav-item mb-2"><a href="#" class="nav-link p-0 text-body-secondary">Schools</a></li>
        </ul>
      </div>

      <div class="col-md-5 offset-md-1 mb-3" style="margin-left:250px;">
        <form id="subscribeForm" action="email.php" method="POST" onsubmit="return validateEmail()">
          <h5>Subscribe For Updates</h5>
          
          <div class="d-flex flex-column flex-sm-row w-100 gap-2">
            <label for="newsletter1" class="visually-hidden">Email address</label>
            <input id="newsletter1" name="email" type="text" class="form-control" placeholder="Email address" required>
            <button class="btn btn-danger" type="submit">Submit</button>
          </div>
          
        </form>
      </div>
    </div>
    <div class="d-flex flex-column flex-sm-row justify-content-between py-4 my-4 border-top">
      <p>© 2024 Company, Inc. All rights reserved.</p>
      <ul class="list-unstyled d-flex">
        <li class="ms-3">
          <a class="link-body-emphasis" href="#">
            <svg class="bi" width="24" height="24">
              <use xlink:href="#twitter"><i class="fa-brands fa-twitter"></i></use>
            </svg>
          </a>
        </li>
        <li class="ms-3"><a class="link-body-emphasis" href="#"><svg class="bi" width="24" height="24"><use xlink:href="#instagram"><i class="fa-brands fa-instagram"></i></use></svg></a></li>
        <li class="ms-3"><a class="link-body-emphasis" href="#"><svg class="bi" width="24" height="24"><use xlink:href="#facebook"><i class="fa-brands fa-facebook-f"></i></use></svg></a></li>
      </ul>
    </div>
  </footer>
</div>

<script>
    function validateEmail() {
        const emailInput = document.getElementById('newsletter1');
        const errorMessage = document.getElementById('error');
        const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

        if (!emailPattern.test(emailInput.value)) {
            errorMessage.textContent = 'Please enter a valid email address.';
            return false; // Prevent form submission
        }

        errorMessage.textContent = ''; // Clear any previous error messages
        return true; // Allow form submission
    }
</script>

<style>
 
 .card1{
  height: auto;
  width: 100%;
 }
 .phali img{
  height: auto;
  height: 100px;
  float: left;
 }
</style>

