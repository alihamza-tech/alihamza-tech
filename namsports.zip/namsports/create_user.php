<?php
session_start();
error_reporting(E_ALL);
ini_set("display error", 1);
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $username = trim($_POST['username']);

    // Server-side validation
    if (empty($username) || strlen($username) < 3 || strlen($username) > 30) {
        $_SESSION['error'] = "Username must be between 3 and 30 characters long.";
        header('Location: index.php');
        exit;
    }

    // SQL query to insert new user
    $sql = "INSERT INTO users (username) VALUES ('$username')";

    if ($conn->query($sql) === TRUE) {
        $_SESSION['success'] = "New user created successfully";
    } else {
        $_SESSION['error'] = "Error: " . $conn->error;
    }

    $conn->close();
    header('Location: index.php');
    exit;
}
?>
