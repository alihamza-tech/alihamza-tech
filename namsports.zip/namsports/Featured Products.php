<h1 class="text-center Feature">Featured Products</h1>

<div class="container" id="cardContainer">
    <div class="card" style="width: 18rem;">
        <img src="assests/Feature products/1.jpg" class="card-img-top" alt="...">
        <div class="card-body feat-pro">
            <h5 class="card-title">Men's Training Pants Regular</h5>
            <p class="card-text"></p>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img src="assests/Feature products/2.jpg" class="card-img-top" alt="...">
        <div class="card-body feat-pro">
            <h5 class="card-title">Men's Training Pant Tapered</h5>
            <p class="card-text"></p>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img src="assests/Feature products/3.jpeg" class="card-img-top" alt="...">
        <div class="card-body feat-pro">
            <h5 class="card-title">Straw Lid Bottle 600ml</h5>
            <p class="card-text"></p>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img src="assests/Feature products/4.jpeg" class="card-img-top" alt="...">
        <div class="card-body feat-pro">
            <h5 class="card-title">Men's T-Shirts Round</h5>
            <p class="card-text"></p>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img src="assests/Feature products/bag.jpeg" class="card-img-top" alt="...">
        <div class="card-body feat-pro">
            <h5 class="card-title">MKL 10 Back Pack</h5>
            <p class="card-text"></p>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img src="assests/Feature products/sho.JPG" class="card-img-top" alt="...">
        <div class="card-body feat-pro">
            <h5 class="card-title">Vinchi Lite Shoes</h5>
            <p class="card-text"></p>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img src="assests/Feature products/boot.jpeg" class="card-img-top" alt="...">
        <div class="card-body feat-pro">
            <h5 class="card-title">Sports Cap Bottle 950ml</h5>
            <p class="card-text"></p>
        </div>
    </div>
    <div class="card" style="width: 18rem;">
        <img src="assests/Feature products/tumb.jpg" class="card-img-top" alt="...">
        <div class="card-body feat-pro">
            <h5 class="card-title">Tumbler with Handle</h5>
            <p class="card-text"></p>
        </div>
    </div>
</div>

<style>
    .container {
        display: flex;
        justify-content: center; 
        flex-wrap: wrap; 
        gap: 20px; 
        padding: 20px; 
    }

    .container .card {
        position: relative;
        overflow: hidden;
        transition: transform 0.3s ease;
        flex: 0 0 22%; 
        max-width: 18rem; 
    }

    .container .card img {
        width: 100%; 
        transition: opacity 0.5s ease; 
    }

    .container .card-body {
        position: absolute;
        top: 50%;
        left: 50%;
        transform: translate(-50%, -50%);
        opacity: 0; 
        transition: opacity 0.5s ease;
        text-align: center;
        padding: 10px; 
         }

    .container .card:hover {
        background-color: rgba(0, 0, 0, 0.7); 
        border: solid white;
    }

   .container .card:hover img {
        opacity: 0.2; 
    }

   .container .card:hover .card-body {
        opacity: 1; 
    }

    .container.card:hover h5 {
        color: white;
    }
</style>
