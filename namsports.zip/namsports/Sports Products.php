<h1 class="text-center Feature" >Sports Products</h1>

<div class="container" id="container">
<div class="card" style="width: 18rem;">
  <img src="assests/Sports/1.jpg" class="card-img-top" alt="...">
  <div class="card-body feat-pro">
    <h5 class="card-title">Shin Guard Adult</h5>
  </div>
  </div>
  <div class="card" style="width: 18rem;">
  <img src="assests/Sports/glo.jpg" class="card-img-top" alt="...">
  <div class="card-body feat-pro">
    <h5 class="card-title">Pro Goal Keeping Gloves</h5>
  </div>
  </div>

  <div class="card" style="width: 18rem;">
  <img src="assests/Sports/bat.jpg" class="card-img-top" alt="...">
  <div class="card-body feat-pro">
    <h5 class="card-title">Pro Bat</h5>
  </div>
  </div>
  <div class="card" style="width: 18rem;">
  <img src="assests/Sports/pad.jpg" class="card-img-top" alt="...">
  <div class="card-body feat-pro">
    <h5 class="card-title">Pro Batting Pad</h5>
  </div>
  </div>
  </div>
