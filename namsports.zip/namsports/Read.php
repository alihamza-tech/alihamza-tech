



<?php
$content = @file_get_contents("NAMSPORTS/login.php");
if($content===false){
    echo "Failed to Open File" . error_get_last()['message'];
}
else{
    echo $content;
}

?>