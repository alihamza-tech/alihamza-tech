<div class="cricket">
<img src="assests/Feature products/cri.jpg" class="img-fluid" alt="..." style="margin-top: 100px;width: 100%;">
<div class="overlay">
            <p class="hover-text">CRCIKET WEAR</p>
        </div>
</div>



<style>

    .cricket img{
       width: 100%;
       /* color: black; */
       opacity: 1;
    }
    .cricket img:hover{
    opacity: 0.6;
    }

    .cricket {
    position: relative;
    width: 100%; /* Aap isko adjust kar sakte hain */
    /* Aapki image ke size ke mutabiq */
}

.cricket img {
    width: 200%; /* Image ko container ke size ke hisaab se adjust karna */
    display: block;
}

.overlay {
    position: absolute;
    top: 0;
    left: 0;
    width: 100%;
    height: 100%;
    background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent background */
    display: flex;
    align-items: center;
    justify-content: center;
    opacity: 0; /* Initial state: hidden */
    transition: opacity 0.3s; /* Transition effect */
}

.cricket:hover .overlay {
    opacity: 1;
    transition: 0.8s all ease-in;
}

.hover-text {
    color: black; /* Text ka rang */
    font-size: 3rem;
     background-color: white;
     cursor: pointer;
}

</style>