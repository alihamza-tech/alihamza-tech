<?php
header('Content-Type: application/json');
include 'db.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents("php://input"));

    if (isset($data->username) && isset($data->password)) {
        // Hash the password
        $passwordHash = password_hash($data->password, PASSWORD_DEFAULT);

        $stmt = $pdo->prepare("INSERT INTO users (username, password) VALUES (:username, :password)");
        
        try {
            $stmt->execute(['username' => $data->username, 'password' => $passwordHash]);
            echo json_encode(['message' => 'Registration successful']);
        } catch (PDOException $e) {
            echo json_encode(['message' => 'Error: ' . $e->getMessage()]);
        }
    } else {
        echo json_encode(['message' => 'Username and password are required']);
    }
} else {
    echo json_encode(['message' => 'Invalid request method']);
}
?>
