<?php
session_start();
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: dashboard.php');
    exit;
}

// Include database connection
$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "namsports";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = $_POST['productName'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_FILES['image'];

    // Validate fields
    if (empty($productName) || empty($description) || empty($price) || empty($image['name'])) {
        die("All fields are required.");
    }
    $check = getimagesize($image["tmp_name"]);
    if ($check === false) {
        die("Uploaded file is not an image.");
    }

    $targetDir = "uploads/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    $targetFile = $targetDir . basename($image["name"]);

    // Upload the file
    if (move_uploaded_file($image["tmp_name"], $targetFile)) {
        $sql = "INSERT INTO products (productName,description , price, image_path) VALUES (?, ?, ?, ?)";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssds", $productName, $description, $price, $targetFile);

        if ($stmt->execute()) {
            echo "Product uploaded successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        die("Error uploading file.");
    }
}
 // Cards won't appear in this case


?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shpezo Software</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="assets/images/logo-side.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
            background-color: #343a40;
            padding: 20px;
        }
        .sidebar a {
            color: #ffffff;
            text-decoration: none;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .upload-form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>

<nav class="sidebar" id="sidebar">
    <h2 class="text-white"><a href="dashboard.php">Shpezo Software</a></h2>
    <ul class="list-unstyled">
        <li class="dropdown">
            <div class="dropdown-header" id="toggleCategories">
                <a href="#" class="dropdown-toggle p-2 d-block" data-bs-toggle="dropdown" aria-expanded="false">
                    Categories
                </a>
                <i class="fa-solid fa-arrow-down"></i>
            </div>
            <ul class="dropdown-menu">
                <li><a href="add_category.php" class="dropdown-item">Add Category</a></li>
                <li><a href="view_categories.php" class="dropdown-item">View Categories</a></li>
            </ul>
        </li>
        <li class="dropdown">
            <div class="dropdown-header" id="toggleProducts">
                <a href="#" class="dropdown-toggle p-2 d-block" data-bs-toggle="dropdown" aria-expanded="false">
                    Products
                </a>
                <i class="fa-solid fa-arrow-down"></i>
            </div>
            <ul class="dropdown-menu">
                <li><a href="upload.php" class="dropdown-item">Add Product</a></li>
                <li><a href="view_products.php" class="dropdown-item">View Products</a></li>
            </ul>
        </li>
        <li><a href="view_users.php" class="p-2 d-block">View Users</a></li>
        <li><a href="settings.php" class="p-2 d-block">Settings</a></li>
        <li><a onclick="confirmLogout()" href="logout.php" class="p-2 d-block">Logout</a></li>
    </ul>
</nav>

<div class="content" id="content">
    <nav class="navbar navbar-expand-lg navbar-light bg-light">
        <div class="container-fluid">
            <button class="btn btn-outline-secondary toggle-btn" id="toggleSidebar">
                <i class="fas fa-bars"></i>
            </button>
            <a class="navbar-brand" href="#">Shpezo Software Dashboard</a>
            <form class="d-flex" id="searchForm">
                <input class="form-control me-2" type="search" placeholder="Search" aria-label="Search">
                <button class="btn btn-outline-dark" type="submit">Search</button>
            </form>
        </div>
    </nav>

    <div class="container mt-4">
        <div class="row">
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-users stats-icon text-primary"></i>
                        <h5 class="card-title">Total Users</h5>
                        <p class="card-text" id="totalUsers">0</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-user-check stats-icon text-success"></i>
                        <h5 class="card-title">Active Users</h5>
                        <p class="card-text" id="activeUsers">0</p>
                    </div>
                </div>
            </div>
            <div class="col-md-4">
                <div class="card text-center">
                    <div class="card-body">
                        <i class="fas fa-cog stats-icon text-warning"></i>
                        <h5 class="card-title">Settings</h5>
                        <p class="card-text"><a href="settings.php" class="text-warning">Manage Settings</a></p>
                    </div>
                </div>
            </div>
        </div>
        
        <!-- Upload Form Section -->
        <div class="row mt-4">
            <div class="col-md-12">
                <div class="upload-form">
                    <h3>Upload Product</h3>
                    <form id="uploadForm" enctype="multipart/form-data" method="POST">
                        <input type="text" name="productName" placeholder="Product Name" class="form-control mb-2" required>
                        <textarea name="description" placeholder="Product Description" class="form-control mb-2" required></textarea>
                        <input type="number" name="price" placeholder="Price" class="form-control mb-2" required>
                        <input type="file" name="image" accept="image/*" class="form-control mb-2" required>
                        <button type="submit" class="btn btn-success">Upload</button>
                    </form>
                    <div id="imageContainer" class="mt-3"></div>
                </div>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.js"></script>
<script>
    // Example data (replace with actual DB data)
    document.getElementById('totalUsers').innerText = 100; // Total users
    document.getElementById('activeUsers').innerText = 50; // Active users

    // Toggle sidebar function
    const toggleButton = document.getElementById('toggleSidebar');
    const sidebar = document.getElementById('sidebar');
    const content = document.getElementById('content');

    toggleButton.addEventListener('click', () => {
        sidebar.classList.toggle('collapsed');
        content.classList.toggle('collapsed');
    });

    // Toggle dropdown functions for categories and products
    const toggleCategories = document.getElementById('toggleCategories');
    const toggleProducts = document.getElementById('toggleProducts');

    toggleCategories.addEventListener('click', (event) => {
        event.preventDefault();
        const dropdownMenu = toggleCategories.nextElementSibling;
        dropdownMenu.classList.toggle('show');
    });

    toggleProducts.addEventListener('click', (event) => {
        event.preventDefault();
        const dropdownMenu = toggleProducts.nextElementSibling;
        dropdownMenu.classList.toggle('show');
    });

    function confirmLogout() {
        if (confirm("Are you sure you want to log out?")) {
            window.location.href = 'logout.php'; // Redirect to logout.php if confirmed
        }
    }
</script>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>




