<?php
include "db.php";
if(isset($_GET['deleteid'])){
    $id = $_GET['deleteid'];

    $sql = "delete  from `products` where id=$id";
    $result=mysqli_query($conn , $sql); 
    if ($result) {
        // echo "Deleted Successfully";
        header('location:view_products.php');
    } else {
       die(mysqli_error($conn));
    }
}
?>
