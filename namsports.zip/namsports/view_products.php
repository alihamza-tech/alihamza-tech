<?php
include 'dashboard.php';     
if (!isset($_SESSION['loggedin']) || $_SESSION['loggedin'] !== true) {
    header('location: login.php');
    exit;
}

$servername = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "namsports";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}




?>


<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Products</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
</head>
<body>
    <div class="content">
        <div class="container mt-4">
            <h2>Product List</h2>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th style="width: 10px;">Num</th>
                        <th>Product Name</th>
                        <th>Description</th>
                        <th>Price</th>
                        <th>Image</th>
                        <th>Operation</th>
                    </tr>
                </thead>
                
                <tbody>
                <?php
$sql = "SELECT * FROM products";
$stmt = mysqli_prepare($conn, $sql);
mysqli_stmt_execute($stmt);
$result = mysqli_stmt_get_result($stmt);

if ($result) {
    while ($row = mysqli_fetch_assoc($result)) {
        
        $id = $row['id'];
        $productName = $row['productName'];
        $description = $row['description'];
        $price = $row['price'];
        $image_path = $row['image_path'];
        echo '<tr>
                <th>'.$id.'</th>
                <td>' . $productName . '</td>
                <td>' . $description . '</td>
                <td>' . $price . '</td>
                <td><img src="' . $image_path . '" alt="' . $productName . '" style="width:100px;height:100px;"></td>
                <td>
                    <button class="btn btn-primary"><a href="update.php?updateid='.$id.'" class="text-light text-decoration-none">Update</a> </button>
                    <button  class="btn btn-danger"><a href="delete.php?deleteid='.$id.'"  class="text-light text-decoration-none">Delete</a></button>
                 </td>
              </tr>';
    }
} 
else {
    echo '<tr><td colspan="4" class="text-center fs-1 text-danger"><b>No products found.</b></td></tr>';
}

// End the table
echo '</table>';
$conn->close();
?>
                </tbody>
            </table>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>