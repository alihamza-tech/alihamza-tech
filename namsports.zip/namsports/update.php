<?php
include "db.php";

$id = $_GET['updateid'];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productName = $_POST['productName'];
    $description = $_POST['description'];
    $price = $_POST['price'];
    $image = $_FILES['image'];

    // Validate fields
    if (empty($productName) || empty($description) || empty($price) || empty($image['name'])) {
        die("All fields are required.");
    }
    $check = getimagesize($image["tmp_name"]);
    if ($check === false) {
        die("Uploaded file is not an image.");
    }

    $targetDir = "uploads/";
    if (!file_exists($targetDir)) {
        mkdir($targetDir, 0777, true);
    }
    $targetFile = $targetDir . basename($image["name"]);


    if (move_uploaded_file($image["tmp_name"], $targetFile)) {
       $sql  = "update `products` SET productName=?,description=?,price=?,image=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("ssdsi", $productName, $description, $price, $targetFile,$id);

        if ($stmt->execute()) {
            echo "Product Updated successfully.";
        } else {
            echo "Error: " . $stmt->error;
        }
    } else {
        die("Error uploading file.");
    }
}

?>

<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Shpezo Software</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" rel="stylesheet">
    <link rel="shortcut icon" href="assets/images/logo-side.jpg" type="image/x-icon">
    <link href="https://cdn.jsdelivr.net/npm/fullcalendar@5.10.1/main.min.css" rel="stylesheet" />
    <style>
        body {
            background-color: #f8f9fa;
        }
        .sidebar {
            height: 100vh;
            position: fixed;
            top: 0;
            left: 0;
            z-index: 100;
            background-color: #343a40;
            padding: 20px;
        }
        .sidebar a {
            color: #ffffff;
            text-decoration: none;
        }
        .content {
            margin-left: 250px;
            padding: 20px;
        }
        .card {
            border: none;
            border-radius: 10px;
            box-shadow: 0 4px 20px rgba(0,0,0,0.1);
        }
        .upload-form {
            background: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
        }
    </style>
</head>
<body>
<div class="container my-5">
                        <form id="uploadForm" enctype="multipart/form-data" method="POST">
                        <input type="text" name="productName" placeholder="Product Name" class="form-control mb-2" required>
                        <textarea name="description" placeholder="Product Description" class="form-control mb-2" required></textarea>
                        <input type="number" name="price" placeholder="Price" class="form-control mb-2" required>
                        <input type="file" name="image" accept="image/*" class="form-control mb-2" required>
                        <button type="submit" class="btn btn-success">Update</button>
                    </form>
</div> 
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
