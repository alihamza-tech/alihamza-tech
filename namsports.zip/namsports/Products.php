<!doctype html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Noms Sports</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css" integrity="sha512-Kc323vGBEqzTmouAECnVceyQqyqdsSiqLQISBL29aUW4U/M7pSPA/gEUZQqv1cwx4OnYxTxve5UMg5GT6L4JJg==" crossorigin="anonymous" referrerpolicy="no-referrer" />
  <link rel="stylesheet" href="style.css">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
  <link rel="shortcut icon" href="assests/images/logo-side.jpg" type="image/x-icon">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
  <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
  <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</head>

</head>
<style>
  #container {
    display: flex;
    flex-direction: row;
    overflow-x: auto;
    white-space: nowrap;
    justify-content: center;
    margin: 20 auto;
    max-width: 100%;
    text-align: center;

  }

  .card {
    display: inline-block;
    margin: 10px;
    width: 18rem;

  }
  .card.custom-card {
    border: 1px solid #ccc;
    border-radius: 8px;
    transition: transform 0.3s, box-shadow 0.3s; 
    box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1);
    width: 90%; 
    max-width: 300px;
    margin: auto; 
    max-height: 550px; 
    overflow: hidden; 
    position: relative; 
}

.card.custom-card:hover {
    transform: scale(1.05); 
    box-shadow: 0 4px 15px rgba(0, 0, 0, 0.2); 
}

.card-body {
    opacity: 0; 
    transition: opacity 0.3s ease; 
    position: absolute; 
    bottom: 0;
    left: 0; 
    right: 0; 
    padding: 15px; 
    background: rgba(255, 255, 255, 0.9); 
}

.card.custom-card:hover .card-body {
    opacity: 1; 
    background: #333;
    cursor: pointer;
}

.card-title {
    color: white; 
}
.card-text{
  color: white;
}

.price {
    font-weight: bold;
    color: white;
}

.divider {
    border: none;
    border-top: 1px solid #ccc;
    margin: 10px 0; 
}



</style>

<body>

  <div class="alert alert-light text-center" role="alert">
    Free shipping on orders over Rs 3000 + free returns
  </div>

  <nav class="navbar navbar-expand-lg bg-body-light">
    <div class="container-fluid">
      <a class="navbar-brand" href="index.php"><img src="assests/images/logo1051011071015335.png" alt=""></a>
      <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarSupportedContent">
        <ul class="navbar-nav me-auto mb-2 mb-lg-0">
          <li class="nav-item"><a class="nav-link" href="#">Men</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Women</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Kids</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Sports</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Accessories</a></li>
          <li class="nav-item"><a class="nav-link" href="#">Schools</a></li>
        </ul>
        <form class="d-flex" role="search" action="search.php" method="GET">
          <input class="form-control me-2" type="search" name="query" placeholder="Search" aria-label="Search">
          <button class="btn btn-outline-light" type="submit">Search</button>
        </form>
      </div>
      <div class="sid-logo">
        <img src="assests/images/logo-side.jpg" alt="">
      </div>
    </div>
  </nav>
  <h1 class="text-center" style="font-weight:700; margin-top:30px;">PRODUCTS</h1>
  <?php
  // Database connection
  $servername = "localhost";
  $username = "root";
  $password = "";
  $dbname = "namsports";

  $conn = new mysqli($servername, $username, $password, $dbname);
  if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
  }


  ?>



  <div class="container">

    <div class="row">


      <?php

      $sql = "SELECT * FROM products";
      $stmt = mysqli_prepare($conn, $sql);
      mysqli_stmt_execute($stmt);
      $result = mysqli_stmt_get_result($stmt);

      if ($result) {
        while ($row = mysqli_fetch_assoc($result)) {

          $id = $row['id'];
          $productName = $row['productName'];
          $description = $row['description'];
          $price = $row['price'];
          $image_path = $row['image_path'];

          echo '


                          <div class="col-12 col-sm-6 col-md-4 col-lg-4 mt-4"> 
                          <div class="card custom-card" > 
                          <img class="card-img-top" src="' . $image_path . '" alt="">     
                           <div class="card-body text-center"> 
                              <h5 class="card-title">' . $productName . '</h5> 
                            <p class="card-text">' . $description . '</p> 
                              <p class="card-text price">' . $price . '</p> 
                              <a href="contect.php">  <button class="btn btn-primary">Buy Now</button></a>
                              </div> 
                              </div>
                          </div>

';




        }
      }


      ?>


    </div>


  </div>

  <?php
  include "footer.php";
  ?>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>

</html>