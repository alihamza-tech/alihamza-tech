



<div id="formContainer">
        <h1 class="text-center">Enter Your Username</h1>
        <form id="accessForm" action="create_user.php" method="POST" onsubmit="return validateForm();">
            <input type="text" name="username" id="username" placeholder="Enter your username" required>
            <input type="submit" value="Submit" id="submit">
        </form>
    </div>

  

    <script>
    function validateForm() {
        const username = document.getElementById('username').value;

        // Condition: Check if username is not empty and has a certain length
        if (username.length < 3 || username.length > 30) {
            alert("Username must be between 3 and 30 characters long.");
            return false; // Prevent form submission
        }

        // If validation passes, show main content and hide form
        document.getElementById('formContainer').style.display = 'none';
        document.getElementById('mainContent').style.display = 'block';
        
        return true; // Allow form submission
    }
    </script>


<style>
    #formContainer{
        margin-top: 50px;
        align-items: center;
        justify-content: center;
        text-align: center;
        padding-top: 50px;
        background-color: rgba(var(--bs-emphasis-color-rgb), 0.65);
        height: 300px;
    }
    #username{
        height: 40px;
        width: 500px;
        padding: 20px;
    }
    .text-center{
        margin-left: -50px;
        color: white;
    }
    #submit{
        all: unset;
        background-color: black;
        color: white;
        height: 40px;
        width: 100px;
        cursor: pointer;
    }
</style>